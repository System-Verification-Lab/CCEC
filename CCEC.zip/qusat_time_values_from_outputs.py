k = 30
l = 30

#creates a file with all the QuSAT running-time outputs which are written at the last line of each QuSAT generated txt.

with open("qusat_times.txt", "w") as output_file:
    for i in range(10, k+1, 10):
        for j in range(10, l+1, 10):
            try:
                with open(f"qusat_output_{i}_{j}.txt", "r") as input_file:
                    lines = input_file.readlines()
                    last_line = lines[-1].strip()
                    last_int = int(''.join(filter(str.isdigit, last_line)))
                    file_name = f"qusat_output_{i}_{j}.txt"
                    output_file.write( f"qusat_output_{i}_{j}," + str(last_int) + "\n" )
            except FileNotFoundError:
                print(f"Could not find file qusat_output_{i}_{j}.txt")

