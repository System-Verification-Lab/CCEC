# # INSTALLATION INSTRUCTIONS
 
# create a python virtual environment
mkdir env
python3 -m venv env
source env/bin/activate
 
 
########
# Stim #
########
 
 
# download Stim and checkout the version of the code that was used
 
git submodule add https://github.com/quantumlib/Stim
 
 
cd Stim
git checkout 80f1b30abcce41c82629beb6f93c837fec40a3e6
cd ..
 
# apply changes
 
patch Stim/src/stim/simulators/tableau_simulator.cc patches/stim_patch.diff
 
# install Stim
# Follow instructions in https://github.com/quantumlib/Stim/blob/main/README.md to install Stim
 
 
#########
# QuSat #
#########
 
 
 
# download QuSat and checkout the version of the code that was used
 
git submodule add git@github.com:cda-tum/qusat.git
 
 
cd qusat
git checkout 974354c2ff96e19d733ada25d46c202acde4afd6
git submodule update --init --recursive
cd ..
 
# apply changes
 
patch qusat/test/test_satencoder.cpp patches/qusat_test-satencoder_patch.diff
patch qusat/extern/qfr/src/algorithms/RandomCliffordCircuit.cpp patches/qusat_RandomCliffordCircuit_patch.diff
 
 
# install QuSat
# Follow instructions in https://github.com/cda-tum/qusat/blob/main/README.md to intall QuSat
# make sure to modify the variables of the "for" loops and the variables "i" and "j" according to the desired experiment. 
 
#######################
# Running numerics    #
#######################
 

 
#the "run_all.py" will run all three python script that are necessary for producing the data. 
#make sure you modify the variables of the "for" loop and also the variables "i" and "k" depending on the desired experiment. (They must be consistent across all three .py scripts) 


python3 run_all.py 